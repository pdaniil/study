<tr><td><b>Привязаные соц сети</b></td> <td>

	<?php 
	$SQL_get_social_connected = "SELECT * FROM `social` AS `soc` INNER JOIN `social_user_data` AS `soc_dat` ON `soc`.`id` = `soc_dat`.`social_id` WHERE `soc_dat`.`user_id` = ?";
	$query = $db_link->prepare($SQL_get_social_connected);
	$query->execute( array( DP_User::getUserId() ) );
	while ($social = $query->fetch())
	{
		?>
		<a href="javascript:void(0);" title="Отвязать" onclick="delete_users_social(<?php echo $social["social_id"];?>)"><img width="40" src="<?php echo "https://".$_SERVER["SERVER_NAME"].$social["social_img_url"]; ?>" /></a>
		<?
	}
	?>

</td></tr>
<tr><td><b>Доступные соц сети</b></td> <td>

	<?php 
					//Выбор id соц сетей, которые у данного пользователя не привязаны
	$SQL_get_social_disconnected = "SELECT * FROM `social` WHERE `id` NOT IN (SELECT `soc`.`id` FROM `social` AS `soc` INNER JOIN `social_user_data` AS `soc_dat` ON `soc`.`id` = `soc_dat`.`social_id` WHERE `soc_dat`.`user_id` = ?); ";
	$query = $db_link->prepare($SQL_get_social_disconnected);
	$query->execute( array( DP_User::getUserId()) );
	while ($social = $query->fetch())
	{
						//Получаем адрес скрипта-обработчика 
		$SQL_select_uri_redirect = "SELECT `uri_redirect` FROM `social_options` WHERE `id_social` = ?;";
		$query_options = $db_link->prepare($SQL_select_uri_redirect);
		$query_options->execute( array( $social["id"] ) );
		$result = $query_options->fetch();
		$uri_redirect = $result["uri_redirect"];
		?>
		<a href = "<?php echo "https://".$_SERVER["SERVER_NAME"].$uri_redirect; ?>" title="Привязать"><img width="40" src="<?php echo "https://".$_SERVER["SERVER_NAME"].$social["social_img_url"]; ?>" /></a>
		<?
	}
	?>

</td></tr>


<script>
	function delete_users_social(social_id)
	{
		let flag = confirm('Вы действительно хотите отвязать данную соц сеть?');
		if (flag)
		{
			jQuery.ajax({
				type: "POST",
		async: false, //Запрос синхронный
		url: "<?php echo 'https://'.$_SERVER['SERVER_NAME'].'/content/users/ajax_delete_social_users.php';?>",
		dataType: "json",//Тип возвращаемого значения
		data: "user_id=<?php echo DP_User::getUserId();?>&social_id="+social_id,
		success: function(answer){
			if(answer.status == true)
			{
				
				location = location;
			}
			else
			{ 
				alert(answer.message);
			}
		}
	});
		}
	}
	
</script>