<?php
class DP_Config
{
	//Общие настройки сайта:
	public $site_name = 'Avtomarket34';//Название сайта
	public $domain_path = 'https://avtomarket34.ru/';//Домен сайта
	public $backend_dir = 'cp';//Каталог бэкэнда
	public $list_page_limit = '20';//Количество элементов на странице списка
	public $min_password_len = '8';//Минимальная длина пароля
	public $description_tag = '';//Тег description
	public $keywords_tag = '';//Тег keywords
	public $main_user_field = 'email';//Главное поле регистрации (телефон или email)
	
	//Настройки вывода title
	public $show_page_title = '1';//Показывать заголовок страницы
	public $show_site_name = '1';//Показывать название сайта
	public $page_title_first = '1';//Заголовок страницы перед названием сайта
	
	//Настройка обновлений
	public $update_server = 'http://updates.intask.pro/';//Сервер обновлений
	public $product = 'docpart';//Продукт
	
	//Настройки БД
	public $host_external = '45.67.57.7';/*Сервер БД для внешних подключений*/
	public $host = 'localhost';/*Сервер БД*/
	public $user = 'admin_avtomarket';/*Пользователь БД*/
	public $password = 'new12345678';/*Пароль БД  JhvMrFJg5m1 */
	public $db = 'admin_new_avtomarket';/*Основная БД*/
	
	//Для акцивации пользователей
	public $secret_succession = '+AWH*TpeQ}N7me4{C:miPYk';/*Код, добавляемый в md5 - для предотвращения подбора кодов активации*/
	
	
	// Настройки почты:
	public $from_name = 'Avtomarket34';//Имя отправителя
	public $from_email = 'avtomarket34@bk.ru';//Адрес отправителя
	public $smtp_mode = '1';//Режим отправки через SMTP-авторизацию. enabled or disabled (включен или выключен)
	public $smtp_encryption = 'ssl';//Шифрование
	public $smtp_host = 'smtp.mail.ru';//Хост почтового сервера
	public $smtp_port = '465';//Порт почтового сервера
	public $smtp_username = 'avtomarket34@bk.ru';//Имя пользователя почтового сервера
	public $smtp_password = 'cEw-ES7-kE6-H9G';//Пароль почтового сервера
	
	
	//Интернет-магазин:
	public $products_count_for_page = '10';/*Количество товаров на одну страницу по умолчанию*/
	public $product_url = 'alias';/*Как вывоить url страниц товаров*/
	public $tech_key = 'H8ugh9)gKLYIp8W0*v7mKc';/*Ключ для вызовов скриптов протокола управления заказами*/
	public $products_table_mode = '0';/*Формат таблицы найденных товаров*/
	public $shop_currency = '643';/*Валюта магазина*/
	public $currency_show_mode = 'sign_before';/*Вариант обозначения валюты*/
	public $price_rounding = '2';/*Округление цен*/
	public $ucats_login = 'avtomarket34.ru';/*Логин каталога Ucats*/
	public $ucats_password = 'kFTWoBjb';/*Пароль каталога Ucats*/
	public $ucats_shiny = '1';/*Показывать каталог Ucats-Шины на главной*/
	public $ucats_disks = '1';/*Показывать каталог Ucats-Диски на главной*/
	public $ucats_accessories = '1';/*Показывать каталог Ucats-Аксессуры на главной*/
	public $ucats_to = '1';/*Показывать каталог Ucats-ТО на главной*/
	public $ucats_oil = '1';/*Показывать каталог Ucats-Масла на главной*/
	public $ucats_akb = '1';/*Показывать каталог Ucats-АКБ на главной*/
	public $ucats_caps = '1';/*Показывать каталог Ucats-Колпаки на главной*/
	public $ucats_bolty = '1';/*Показывать каталог Ucats-Болты на главной*/
	public $suppliers_api_debug = '1';/*Включить отладку API поставщиков*/
	
	
	//Настройки почты для загрузки прайс-листов
	public $prices_email_server = 'imap.yandex.ru';/*Почтовый сервер*/
	public $prices_email_encryption = 'ssl';/*Шифрование*/
	public $prices_email_port = '993';/*Порт*/
	public $prices_email_username = 'price@avtomarket34.ru';/*Пользователь*/
	public $prices_email_password = 'zJ9-LgP-Hm5-UGx';/*Пароль*/
	
	
	//Технические настройки
	public $tmp_dir_prices_upload = '/tmp/prices_upload_files';/*Путь к временному каталогу для загрузки прайс-листов*/
	public $access_cart_record_time = '21600';/* Количество сек. до блокировки позиции в корзине */
	public $catalogue_html_way = 'pagination';/*Способ отображения каталога для покупателя*/
	public $allow_edit_system_content = '1';/*Разрешить редактирование системных материалов*/
	public $markup_yandex_delivery = '70'; //Для яндекс доставки
	public $my_storages_id = '98,87, 55, 54, 84,19,21,24,61,20,26,35,36,47,48,,49,50,52,56,57,58,59,60,61,62,63,74,77,76,78,81,82,83,91,95,96';/* Список id складов через запятую, которые поднимаются выше остальных в проценке */
	

	public function getDateByTimeToExe($time_to_exe, $garant_to_exe = null) {

		// Рассчитываем дату, исходя из значения Время доставки товара (проценка)
		// Если гарантированный срок больше ожидаемого на 3 дня то рассчитываем среднее значение между гарантированным и ожидаемым и так же находим дату: текущая дата плюс найденный средний срок.
		// Затем смотрим если в промежутке от текущего дня до ожидаемого дня поставки были воскресения то к ожидаемому сроку прибавляем столько дней сколько было воскресений.
		// И если попадаем на воскресенье то прибавляем еще один день.
		// Затем отображаем дату в колонке.

		$check_s = false; // Делаем проверку на воскресенье, добавляем 1 день
		$result = '';

		if($garant_to_exe == null) {
			$garant_to_exe = $time_to_exe;
		}

		$nowtime = time();
		
		// Если текущий день воскресенье то прибавляем еще сутки
		if($check_s) {
			$is_sunday = date('w', $nowtime);
			if($is_sunday == 0){
				$nowtime += 86400;
			}


		}
			
		// Если гарантированный срок больше ожидаемого на 3 дня то рассчитываем среднее значение между гарантированным и ожидаемым и так же находим дату: текущая дата плюс найденный средний срок.
		// if( ($time_to_exe_garanted - $tmp_time_to_exe) > 3){
		// 	$sred_srok = $time_to_exe_garanted - $tmp_time_to_exe;
		// 	$sred_srok = (int)($sred_srok / 2);
		// 	$sred_srok = $tmp_time_to_exe + $sred_srok;
		// 	if($sred_srok < 1){
		// 		$sred_srok = 1;
		// 	}
		// }else{
		// 	$sred_srok = $time_to_exe_garanted;
		// }
		
		$datetime = $nowtime + ($time_to_exe * 86400);
		
		//Затем смотрим если в промежутке от текущего дня до ожидаемого дня поставки были воскресения то к ожидаемому сроку прибавляем столько дней сколько было воскресений.
		// $cnt_vs = 0;
		// for($ii = 1; $ii <= $sred_srok; $ii++ ){
		// 	$w = date('w', $time + ($ii * 86400));
		// 	if($w == 0){
		// 		$cnt_vs++;
		// 	}
		// }
		
		//Получаем итоговую дату. 
		$result = date('d.m.Y', $datetime);

		return $result;
	}
}
?>